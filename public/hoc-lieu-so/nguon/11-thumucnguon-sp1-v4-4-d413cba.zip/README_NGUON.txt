THƯ MỤC NGUỒN SẢN PHẨM 1: CẤP SỐ NHÂN - TOÁN 11
=================================================
PHIÊN BẢN: V4.4 - 28/07/2026

1. CẤU TRÚC
- ma_nguon_bai_giang/: toàn bộ mã HTML5, CSS, JavaScript, 35 bản thu MP3 và manifest SCORM 1.2.
- tai_lieu_goc/: tài liệu chuyên đề do tác giả cung cấp.
- kich_ban/: storyboard chi tiết theo từng slide.
- tao_giao_an/: mã nguồn dùng để dựng giáo án PDF.

2. CHỈNH THÔNG TIN TÁC GIẢ
- Mở ma_nguon_bai_giang/config.js.
- Thay email và organization; giữ nguyên dấu ngoặc kép và dấu phẩy.
- Đồng thời cập nhật hai trường tương ứng trong giáo án trước khi nộp chính thức.

3. DỰNG LẠI GÓI BÀI GIẢNG
- Nén trực tiếp các tệp bên trong ma_nguon_bai_giang/.
- imsmanifest.xml phải nằm ngay ở cấp đầu tiên của baigiang_sp1_V4_4.zip.
- Không đặt thêm một thư mục bao ngoài manifest.

4. KIỂM TRA TỐI THIỂU
- Mở index.html và đi hết 35 màn hình.
- Ở từng màn hình, xác nhận nút Tiếp tục bị ẩn trước khi nghe hết MP3 và chỉ xuất hiện sau khi bản thu kết thúc ít nhất một lần.
- Thử cả đáp án đúng và sai ở 7 câu; xác nhận nút Tiếp tục chỉ xuất hiện khi vừa nghe đủ, vừa trả lời đúng.
- Kiểm tra các nhiệm vụ bắt buộc: chọn đúng hai quy luật, điền đúng ba số hạng, chọn đúng quy luật của bóng nảy, đếm số mũ, xác định dữ kiện tăng trưởng, phân loại đúng bốn tình huống và khám phá tính chất đối xứng.
- Ở slide 13, chạy hoạt ảnh bóng nảy, xác nhận tâm quả bóng đi đúng trên đường quỹ đạo nét đứt và kiểm tra câu hỏi kết nối.
- Ở slide 14, 17, 18 và 24, xác nhận kết luận chỉ xuất hiện sau tương tác đúng.
- Ở slide 21, kéo–thả bằng chuột; sau đó thử phương án chạm thẻ rồi chạm vùng đích trên màn hình cảm ứng.
- Kiểm tra đủ 35 tệp audio/slide-01.mp3 đến audio/slide-35.mp3.
- Bấm Bắt đầu và Tiếp tục để xác nhận bản thu cũ dừng, bản thu của slide mới phát ngay; thử đủ Nghe/Tiếp tục, Tạm dừng, Nghe lại và thanh tiến độ.
- Bấm biểu tượng q ở đầu thanh bên để bật chế độ giáo viên; xác nhận danh sách đủ 35 slide, mọi học phần đều mở và có thể chuyển tự do không cần nghe đủ audio.
- Trong chế độ giáo viên, chọn một slide bất kì rồi bấm Thoát; xác nhận hệ thống trở lại đúng slide và tiến độ học sinh trước khi bật chế độ.
- Kiểm tra KaTeX ngoại tuyến trên đủ 35 slide: không có công thức lỗi, không còn thẻ sub/sup tự dựng, không mất chỉ số hoặc số mũ.
- Kiểm tra các công thức dài ở màn hình 22, 23, 24, 25, 27, 31 và 34 trên cả máy tính lẫn điện thoại; công thức phải giữ nguyên một dòng và cuộn trong khung nếu cần.
- Xác nhận thư mục ma_nguon_bai_giang/vendor/katex có tệp CSS, JavaScript và toàn bộ phông toán đi kèm.
- Nhập ZIP lên một LMS hỗ trợ SCORM 1.2 để xác nhận điểm, trạng thái và vị trí học.
- Kiểm tra trên màn hình máy tính và điện thoại, có và không có kết nối Internet.

5. BẢN QUYỀN
- Mã, biểu đồ và minh họa được dựng mới cho bài giảng này.
- Giấy phép: CC BY-SA 4.0.
