from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    KeepTogether,
    LongTable,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "master" / "giaoan_sp1.pdf"

NAVY = colors.HexColor("#17324D")
TEAL = colors.HexColor("#159E91")
BLUE = colors.HexColor("#2B73C9")
INK = colors.HexColor("#20364A")
MUTED = colors.HexColor("#657788")
LINE = colors.HexColor("#D8E5EA")
MINT = colors.HexColor("#E6F5F2")
SKY = colors.HexColor("#EDF6FB")
WARM = colors.HexColor("#FFF3EC")

font_dir = Path("/usr/share/fonts/truetype/dejavu")
pdfmetrics.registerFont(TTFont("DV", str(font_dir / "DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont("DV-Bold", str(font_dir / "DejaVuSans-Bold.ttf")))
pdfmetrics.registerFont(TTFont("DV-Oblique", str(font_dir / "DejaVuSans.ttf")))

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(
    name="BodyVN", fontName="DV", fontSize=9.2, leading=13.6,
    textColor=INK, spaceAfter=5,
))
styles.add(ParagraphStyle(
    name="SmallVN", fontName="DV", fontSize=8, leading=11.5,
    textColor=INK,
))
styles.add(ParagraphStyle(
    name="TinyVN", fontName="DV", fontSize=7.2, leading=10.2,
    textColor=INK,
))
styles.add(ParagraphStyle(
    name="H1VN", fontName="DV-Bold", fontSize=16, leading=20,
    textColor=NAVY, spaceBefore=10, spaceAfter=8,
))
styles.add(ParagraphStyle(
    name="H2VN", fontName="DV-Bold", fontSize=12, leading=16,
    textColor=BLUE, spaceBefore=8, spaceAfter=5,
))
styles.add(ParagraphStyle(
    name="CoverTop", fontName="DV-Bold", fontSize=10, leading=14,
    textColor=TEAL, alignment=TA_CENTER, spaceAfter=10,
))
styles.add(ParagraphStyle(
    name="CoverTitle", fontName="DV-Bold", fontSize=28, leading=33,
    textColor=NAVY, alignment=TA_CENTER, spaceAfter=8,
))
styles.add(ParagraphStyle(
    name="CoverSub", fontName="DV", fontSize=12, leading=17,
    textColor=MUTED, alignment=TA_CENTER, spaceAfter=12,
))
styles.add(ParagraphStyle(
    name="TableHead", fontName="DV-Bold", fontSize=7.8, leading=10.5,
    textColor=colors.white, alignment=TA_CENTER,
))
styles.add(ParagraphStyle(
    name="TableCell", fontName="DV", fontSize=7.4, leading=10.5,
    textColor=INK,
))
styles.add(ParagraphStyle(
    name="TableCellBold", fontName="DV-Bold", fontSize=7.5, leading=10.5,
    textColor=NAVY,
))


def P(text, style="BodyVN"):
    return Paragraph(text, styles[style])


def bullets(items):
    return [P(f"• {item}") for item in items]


def header_footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(LINE)
    canvas.setLineWidth(0.5)
    canvas.line(1.7 * cm, A4[1] - 1.25 * cm, A4[0] - 1.7 * cm, A4[1] - 1.25 * cm)
    canvas.setFont("DV-Bold", 7.5)
    canvas.setFillColor(MUTED)
    canvas.drawString(1.7 * cm, A4[1] - 1.02 * cm, "KẾ HOẠCH BÀI DẠY E-LEARNING · TOÁN 11")
    canvas.setFont("DV", 7.5)
    canvas.drawRightString(A4[0] - 1.7 * cm, 0.85 * cm, f"Trang {doc.page}")
    canvas.restoreState()


doc = BaseDocTemplate(
    str(OUT),
    pagesize=A4,
    leftMargin=1.7 * cm,
    rightMargin=1.7 * cm,
    topMargin=1.6 * cm,
    bottomMargin=1.35 * cm,
    title="Kế hoạch bài dạy E-learning: Cấp số nhân - Toán 11",
    author="Nguyễn Trọng Hiếu",
)
frame = Frame(
    doc.leftMargin, doc.bottomMargin, doc.width, doc.height,
    leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0,
)
doc.addPageTemplates([PageTemplate(id="main", frames=[frame], onPage=header_footer)])

story = []
story += [
    Spacer(1, 1.2 * cm),
    P("BỘ GIÁO DỤC VÀ ĐÀO TẠO<br/>CUỘC THI THIẾT KẾ BÀI GIẢNG ĐIỆN TỬ", "CoverTop"),
    Spacer(1, 0.35 * cm),
    P("KẾ HOẠCH BÀI DẠY<br/>E-LEARNING", "CoverSub"),
    P("CẤP SỐ NHÂN", "CoverTitle"),
    P("Môn Toán - Lớp 11", "CoverSub"),
]

meta = [
    [P("Tác giả", "TableCellBold"), P("Nguyễn Trọng Hiếu", "TableCell")],
    [P("Email", "TableCellBold"), P("[Bổ sung email]", "TableCell")],
    [P("Đơn vị công tác", "TableCellBold"), P("[Bổ sung đơn vị công tác]", "TableCell")],
    [P("Thời lượng", "TableCellBold"), P("23-25 phút tự học có hướng dẫn", "TableCell")],
    [P("Hình thức", "TableCellBold"), P("HTML5 đáp ứng; SCORM 1.2; chạy trực tuyến hoặc ngoại tuyến", "TableCell")],
    [P("Giấy phép", "TableCellBold"), P("CC BY-SA 4.0", "TableCell")],
    [P("Thời gian", "TableCellBold"), P("Tháng 07/2026", "TableCell")],
]
t = Table(meta, colWidths=[4 * cm, 10.2 * cm], hAlign="CENTER")
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (0, -1), MINT),
    ("BOX", (0, 0), (-1, -1), 0.8, LINE),
    ("INNERGRID", (0, 0), (-1, -1), 0.45, LINE),
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ("LEFTPADDING", (0, 0), (-1, -1), 9),
    ("RIGHTPADDING", (0, 0), (-1, -1), 9),
    ("TOPPADDING", (0, 0), (-1, -1), 7),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
]))
story += [Spacer(1, 0.45 * cm), t, Spacer(1, 0.55 * cm)]

callout = Table([[P(
    "<b>Định hướng:</b> Bài học tổ chức theo chu trình dự đoán - thao tác - khái quát hóa - "
    "luyện tập - phản hồi tức thời; học sinh được tự điều khiển tốc độ học và học bù theo nhóm lỗi.",
    "BodyVN",
)]], colWidths=[15.7 * cm])
callout.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, -1), SKY),
    ("BOX", (0, 0), (-1, -1), 1, BLUE),
    ("LEFTPADDING", (0, 0), (-1, -1), 11),
    ("RIGHTPADDING", (0, 0), (-1, -1), 11),
    ("TOPPADDING", (0, 0), (-1, -1), 9),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
]))
story += [callout, PageBreak()]

story += [P("I. Mục tiêu bài học", "H1VN"), P("1. Kiến thức", "H2VN")]
story += bullets([
    "Nhận biết được cấp số nhân; xác định số hạng đầu u₁ và công bội q.",
    "Giải thích và vận dụng được công thức uₙ = u₁qⁿ⁻¹.",
    "Vận dụng được công thức tổng n số hạng đầu; xử lí riêng trường hợp q = 1.",
    "Mô hình hóa tình huống tăng trưởng, suy giảm và lũy kế bằng cấp số nhân.",
])
story += [P("2. Kĩ năng và năng lực toán học", "H2VN")]
story += bullets([
    "Nhận dạng quy luật từ bảng số, sơ đồ, đồ thị và tình huống thực tiễn.",
    "Giải quyết vấn đề theo bốn bước: chọn mốc, tìm q, đếm thời đoạn, chọn uₙ hoặc Sₙ.",
    "Sử dụng mô phỏng, thanh trượt và phản hồi tự động để kiểm chứng dự đoán.",
    "Trình bày lập luận; kiểm tra đơn vị, sai số, phép làm tròn và tính hợp lí của kết quả.",
])
story += [P("3. Phẩm chất và năng lực tự học", "H2VN")]
story += bullets([
    "Chủ động thử nghiệm, tự phát hiện lỗi và lựa chọn lộ trình học bù.",
    "Trung thực khi làm đánh giá; kiên trì điều chỉnh sau phản hồi.",
])

story += [P("II. Thiết bị, học liệu và yêu cầu kĩ thuật", "H1VN")]
tech = [
    [P("Thành phần", "TableHead"), P("Yêu cầu", "TableHead")],
    [P("Thiết bị", "TableCellBold"), P("Máy tính, máy tính bảng hoặc điện thoại; loa/tai nghe là tùy chọn.", "TableCell")],
    [P("Trình duyệt", "TableCellBold"), P("Chrome, Edge hoặc Firefox phiên bản hiện đại; JavaScript được bật.", "TableCell")],
    [P("Bài giảng", "TableCellBold"), P("HTML5 đáp ứng; chạy ngoại tuyến; gói SCORM 1.2; tự lưu tiến độ.", "TableCell")],
    [P("Hỗ trợ tiếp cận", "TableCellBold"), P("Phụ đề, cỡ chữ lớn, giảm chuyển động, điều khiển bàn phím và 35 bản thu MP3 riêng cho từng slide; hỗ trợ tự phát và phát/dừng thủ công.", "TableCell")],
    [P("Đánh giá", "TableCellBold"), P("7 câu bắt buộc; được thử lại; trả lời đúng mới mở trang kế tiếp; ngưỡng hoàn thành 7/7.", "TableCell")],
]
t = Table(tech, colWidths=[4.2 * cm, 11.5 * cm], repeatRows=1)
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), NAVY),
    ("BACKGROUND", (0, 1), (0, -1), MINT),
    ("GRID", (0, 0), (-1, -1), 0.45, LINE),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("LEFTPADDING", (0, 0), (-1, -1), 7),
    ("RIGHTPADDING", (0, 0), (-1, -1), 7),
    ("TOPPADDING", (0, 0), (-1, -1), 6),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
]))
story += [t, PageBreak()]

story += [P("III. Tiến trình tổ chức bài học", "H1VN")]
headers = [
    P("Hoạt động<br/>Thời lượng", "TableHead"),
    P("Mục tiêu - nhiệm vụ", "TableHead"),
    P("Hoạt động của học sinh", "TableHead"),
    P("Hỗ trợ của hệ thống", "TableHead"),
    P("Sản phẩm - đánh giá", "TableHead"),
]
rows = [
    [
        P("<b>1. Khởi động</b><br/>Slide 1-4<br/>2 phút", "TableCell"),
        P("Gợi nhu cầu tìm quy luật nhân; xác định mục tiêu học.", "TableCell"),
        P("Dự đoán số hạt trên bàn cờ; kéo thanh n; nhận xét tốc độ tăng.", "TableCell"),
        P("Mô phỏng bàn cờ; biểu diễn 2ⁿ⁻¹; câu hỏi dự đoán không chấm điểm.", "TableCell"),
        P("Nhận xét: hiệu không cố định, tỉ số liên tiếp giữ nguyên.", "TableCell"),
    ],
    [
        P("<b>2. Nhận biết</b><br/>Slide 5-12<br/>4 phút", "TableCell"),
        P("Nhận biết cấp số nhân; xác định q và vai trò của q.", "TableCell"),
        P("Chọn quy luật cho hai dãy; thử các trường hợp q; điền u₃, u₄, u₅; làm câu 1-2.", "TableCell"),
        P("Phản hồi theo lỗi: nhầm hiệu với tỉ số; chỉ kiểm tra một cặp; lệch chỉ số.", "TableCell"),
        P("Xác định đúng q; hoàn thành đúng 2/2 câu kiểm tra.", "TableCell"),
    ],
    [
        P("<b>3. Số hạng uₙ</b><br/>Slide 13-20<br/>5 phút", "TableCell"),
        P("Giải thích số mũ n-1; dùng uₙ trong bài toán tăng trưởng.", "TableCell"),
        P("Điều khiển bóng nảy; kéo n; thay u₁, q, n; đọc đồ thị; làm câu 3-4.", "TableCell"),
        P("Timeline đếm khoảng; đồ thị Canvas; phản hồi lỗi số mũ, công bội và số thời đoạn.", "TableCell"),
        P("Dùng đúng uₙ = u₁qⁿ⁻¹; mô hình q = 1 + r.", "TableCell"),
    ],
    [
        P("<b>4. Tổng Sₙ</b><br/>Slide 21-29<br/>6 phút", "TableCell"),
        P("Phân biệt uₙ với Sₙ; dựng và vận dụng công thức tổng.", "TableCell"),
        P("Phân loại tình huống; từng bước triệt tiêu hai hàng; quan sát tòa tháp và biểu đồ; làm câu 5-6.", "TableCell"),
        P("Mở công thức theo bước; kiểm tra riêng q=1; chẩn đoán nhầm số hạng cuối với tổng.", "TableCell"),
        P("Chọn đúng uₙ/Sₙ; tính được S₆ và S₉.", "TableCell"),
    ],
    [
        P("<b>5. Mô hình hóa</b><br/>Slide 30-33<br/>4 phút", "TableCell"),
        P("Vận dụng quy trình 4 bước cho tăng trưởng và suy giảm.", "TableCell"),
        P("Chọn từng bước; so sánh q; xử lí tảng băng và chu kì bán rã; làm câu 7.", "TableCell"),
        P("Hai tab suy giảm; đồ thị so sánh; phản hồi lỗi q, chu kì và làm tròn.", "TableCell"),
        P("Mô hình đúng; làm tròn sau cùng; câu 7 chính xác.", "TableCell"),
    ],
    [
        P("<b>6. Tổng kết</b><br/>Slide 34-35<br/>4 phút", "TableCell"),
        P("Hệ thống hóa kiến thức; tự đánh giá và chọn lộ trình tiếp theo.", "TableCell"),
        P("Đọc bản đồ khái niệm; xem điểm theo nhóm; học bù hoặc ghi nhận hoàn thành.", "TableCell"),
        P("Dashboard 4 nhóm năng lực; lưu điểm và trạng thái vào SCORM/LMS.", "TableCell"),
        P("Đạt 7/7; hoàn thành toàn bộ các điểm kiểm tra bắt buộc.", "TableCell"),
    ],
]
process_table = LongTable(
    [headers] + rows,
    colWidths=[2.5 * cm, 3.05 * cm, 3.55 * cm, 3.4 * cm, 3.2 * cm],
    repeatRows=1,
)
process_table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), NAVY),
    ("BACKGROUND", (0, 1), (0, -1), MINT),
    ("GRID", (0, 0), (-1, -1), 0.45, LINE),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("LEFTPADDING", (0, 0), (-1, -1), 5),
    ("RIGHTPADDING", (0, 0), (-1, -1), 5),
    ("TOPPADDING", (0, 0), (-1, -1), 5),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
]))
story += [process_table, PageBreak()]

story += [P("IV. Ma trận đánh giá và phản hồi", "H1VN")]
assessment = [
    [P("Câu", "TableHead"), P("Nội dung", "TableHead"), P("Năng lực", "TableHead"), P("Lỗi được chẩn đoán", "TableHead"), P("Điểm học bù", "TableHead")],
    [P("1", "TableCellBold"), P("Nhận diện cấp số nhân", "TableCell"), P("Tư duy và lập luận", "TableCell"), P("Nhầm hiệu với tỉ số; chỉ kiểm tra một cặp.", "TableCell"), P("Slide 7-8", "TableCell")],
    [P("2", "TableCellBold"), P("Tính tiếp u₄, u₅", "TableCell"), P("Giải quyết vấn đề", "TableCell"), P("Lệch chỉ số; dùng quy luật cộng.", "TableCell"), P("Slide 10", "TableCell")],
    [P("3", "TableCellBold"), P("Dùng uₙ", "TableCell"), P("Tư duy và lập luận", "TableCell"), P("Dùng số mũ n thay cho n-1.", "TableCell"), P("Slide 14-15", "TableCell")],
    [P("4", "TableCellBold"), P("Mô hình tăng dân số", "TableCell"), P("Mô hình hóa", "TableCell"), P("Sai q; sai số thời đoạn.", "TableCell"), P("Slide 18", "TableCell")],
    [P("5", "TableCellBold"), P("Tính S₆", "TableCell"), P("Giải quyết vấn đề", "TableCell"), P("Quên u₁; nhầm u₆ với S₆.", "TableCell"), P("Slide 22-23", "TableCell")],
    [P("6", "TableCellBold"), P("Tổng diện tích 9 tầng", "TableCell"), P("Mô hình hóa", "TableCell"), P("Nhầm tổng hữu hạn với tổng vô hạn.", "TableCell"), P("Slide 25", "TableCell")],
    [P("7", "TableCellBold"), P("Chu kì bán rã", "TableCell"), P("Mô hình hóa", "TableCell"), P("Sai số chu kì; làm tròn sớm.", "TableCell"), P("Slide 31", "TableCell")],
]
t = Table(assessment, colWidths=[1.3 * cm, 3.7 * cm, 3.1 * cm, 4.7 * cm, 2.9 * cm], repeatRows=1)
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), NAVY),
    ("BACKGROUND", (0, 1), (0, -1), MINT),
    ("GRID", (0, 0), (-1, -1), 0.45, LINE),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("ALIGN", (0, 1), (0, -1), "CENTER"),
    ("LEFTPADDING", (0, 0), (-1, -1), 6),
    ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ("TOPPADDING", (0, 0), (-1, -1), 6),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
]))
story += [t, Spacer(1, 0.35 * cm)]
story += bullets([
    "Mỗi câu phải trả lời đúng mới mở nút Tiếp tục; học sinh được thử lại không giới hạn và nhận phản hồi theo từng phương án.",
    "Ngưỡng hoàn thành là 7/7. Hệ thống ghi điểm thô, trạng thái đạt/chưa đạt và vị trí học vào SCORM.",
    "Các nhiệm vụ chọn quy luật, điền số và phân loại cũng yêu cầu đúng toàn bộ; khi chưa đạt, hệ thống ẩn nút Tiếp tục và chỉ dẫn điểm cần sửa.",
])

story += [P("V. Phân hóa và hỗ trợ tiếp cận", "H1VN")]
story += bullets([
    "Học sinh cần hỗ trợ: bật phụ đề, cỡ chữ lớn, giảm chuyển động; dùng timeline và gợi ý theo bước.",
    "Học sinh đạt sớm: thay đổi q âm, q có giá trị tuyệt đối lớn hơn 1; giải thích hành vi bằng đồ thị.",
    "Thiết kế không khóa người học sau câu sai; các nút dùng được bằng chuột, cảm ứng và bàn phím.",
    "Không dùng hình ảnh bên ngoài; mọi hình minh họa được dựng mới, giảm rủi ro bản quyền.",
])

story += [P("VI. Tài liệu tham khảo và bản quyền", "H1VN")]
refs = [
    "Tài liệu chuyên đề “Cấp số nhân” do tác giả cung cấp.",
    "Bộ Giáo dục và Đào tạo (2021), Quyết định 2915/QĐ-BGDĐT về Thể lệ Cuộc thi Thiết kế bài giảng điện tử.",
    "Advanced Distributed Learning, Sharable Content Object Reference Model (SCORM) 1.2.",
    "Học liệu, hình minh họa, biểu đồ và mã tương tác trong sản phẩm phát hành theo giấy phép CC BY-SA 4.0.",
]
story += [P(f"{i}. {ref}") for i, ref in enumerate(refs, 1)]

doc.build(story)
print(OUT)
